#pragma once

namespace Globals
{
	UGameEngine* GEngine;
	AOnlineBeaconHost* Beacon;
}