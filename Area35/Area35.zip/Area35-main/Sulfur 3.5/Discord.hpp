﻿#pragma once
#include "framework.h"
#include <fstream>

namespace Discord
{

    ABP_SafeZoneStorm_C* CurrentStorm;
	
	const std::string BOT_TOKEN = "OTc4MDA2Nzg4MTk4Nzg5MTcx.GF9YWq.gijYIIRQ_DaZ6phxrmLDtCa6ApsxT8u3oaaB6U";
    const char PREFIX = '?';

    std::vector<std::string> TempUsers = {};

    static void eraseSubStr(std::string& mainStr, const std::string& toErase)
    {
        // Search for the substring in string
        size_t pos = mainStr.find(toErase);
        if (pos != std::string::npos)
        {
            // If found then erase it from string
            mainStr.erase(pos, toErase.length());
        }
    }

    inline std::wstring convert(const std::string& as)
    {
        // deal with trivial case of empty string
        if (as.empty())    return std::wstring();

        // determine required length of new string
        size_t reqLength = ::MultiByteToWideChar(CP_UTF8, 0, as.c_str(), (int)as.length(), 0, 0);

        // construct new string of required length
        std::wstring ret(reqLength, L'\0');

        // convert old string to new string
        ::MultiByteToWideChar(CP_UTF8, 0, as.c_str(), (int)as.length(), &ret[0], (int)ret.length());

        // return new string ( compiler should optimize this away )
        return ret;
    }

	static void Init()
	{
        dpp::cluster bot(BOT_TOKEN, dpp::intents::i_all_intents);

        bot.on_log(dpp::utility::cout_logger());

        bot.on_message_create([](const dpp::message_create_t& event) {
            auto Message = event.msg.content;

            if (!Message.starts_with(PREFIX))
                return;

            Message = Message.erase(0, 1);

            if (Message.size() == 0)
                return;

            std::transform(Message.begin(), Message.end(), Message.begin(),
                [](unsigned char c) { return std::tolower(c); });

            if (Message.starts_with("status"))
            {

                auto GameState = (AFortGameStateAthena*)World->GameState;


                if ((GameState->GamePhase != EAthenaGamePhase::Warmup && GameState->GamePhase != EAthenaGamePhase::None))
                {

                    dpp::embed sembed;
                    sembed.set_description("Server is up, But Match Is In Progress");
                    sembed.set_title("Match in Progress");
                    sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978221458151047168/EWyt1W8X0AE4gMi.jpg");

                    dpp::message emessage;

                    emessage.add_embed(sembed);

                    event.reply(emessage);
                }
                else
                {
                    dpp::embed sembed;
                    sembed.set_description("Server is up, and is Joinable");
                    sembed.set_title("Match is Avaliable");
                    sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978197398268542997/EW4ZV9YWkAAzPXA.jpg");

                    dpp::message emessage;

                    emessage.add_embed(sembed);

                    event.reply(emessage);
                }

                return;
            }

            if (event.msg.member.user_id != 876779140936769546 && event.msg.member.user_id != 361006719385468928 && event.msg.member.user_id != 734344338573885510 && event.msg.member.user_id != 907508382682980362 && event.msg.member.user_id != 793120021907636238 && event.msg.member.user_id != 600113281302265876 && event.msg.member.user_id != 324306541849083904 && event.msg.member.user_id != 525840302120894464 && event.msg.member.user_id != 819566161846075403 && event.msg.member.user_id != 394540865592492042)
            {
                bool bTempUser = false;

                for (auto TempUser : TempUsers)
                {
                    if (std::to_string(event.msg.member.user_id) == TempUser)
                        bTempUser = true;
                }

                if (!bTempUser)
                {
                    dpp::embed sembed;
                    sembed.set_description("You are not a developer or a owner!!!");
                    sembed.set_title("Error Processing Your Request");
                    sembed.set_image("https://cdn.discordapp.com/attachments/978007310481899563/978200913359552512/FSxLvyGUUAIrbUZ.jpg");

                    dpp::message emessage;

                    emessage.add_embed(sembed);

                    event.reply(emessage);
                    return;
                }
            }


            if (Message.starts_with("add "))
            {
                eraseSubStr(Message, "add ");
                try
                {
                    TempUsers.push_back(Message);
                }
                catch (std::exception ex)
                {
                    dpp::embed sembed;
                    sembed.set_description("Uh Oh, " + std::string(ex.what()));
                    sembed.set_title("Error Processing Your Request");
                    sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978221458151047168/EWyt1W8X0AE4gMi.jpg");

                    dpp::message emessage;

                    emessage.add_embed(sembed);

                    event.reply(emessage);

                    return;
                }

                dpp::embed sembed;
                sembed.set_description("Added User!");
                sembed.set_title("Processing Request Successfully");
                sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978197398268542997/EW4ZV9YWkAAzPXA.jpg");

                dpp::message emessage;

                emessage.add_embed(sembed);

                event.reply(emessage);
            }

            if (Message.starts_with("kick "))
            {
                eraseSubStr(Message, "kick ");

                std::string Players = std::string();

                dpp::embed sembed;

                for (int i = 0; i < World->NetDriver->ClientConnections.Num(); i++)
                {
                    auto Connection = World->NetDriver->ClientConnections[i];
                    auto PlayerController = Connection->PlayerController;

                    if (!PlayerController)
                        continue;

                    if (!PlayerController->Pawn)
                        continue;

                    auto PlayerState = PlayerController->PlayerState;

                    if (!PlayerState)
                        continue;

                    FString IP;
                    (*(__int64(__fastcall**)(UNetConnection*, FString*))(*(__int64*)__int64(Connection) + 584))(Connection, &IP);

                    std::string PlayerName = std::string();

                    for (auto Char : Connection->RequestURL.ToString())
                    {
                        if (Char == '=' && PlayerName.size() != 0)
                            break;

                        if (Char == '?' && PlayerName.size() != 0)
                            break;

                        if (Char == '=' && PlayerName.size() == 0 || PlayerName.size() != 0)
                            PlayerName += Char;
                    }

                    PlayerName = PlayerName.erase(0, 1);

                    std::transform(PlayerName.begin(), PlayerName.end(), PlayerName.begin(),
                        [](unsigned char c) { return std::tolower(c); });

                    if (PlayerName == Message)
                    {
                        PlayerController->ClientReturnToMainMenu(L"You have been kicked, L + Bozo.");
                    }
                }
            }

            if (Message.starts_with("setgamemode "))
            {
                eraseSubStr(Message, "setgamemode ");

                std::string Status;

                if (Message.starts_with("duos"))
                {
                    Currentgm = EGamemode::Duos;
                    Status = "duos";
                }
                else if (Message.starts_with("endgame"))
                {
                    if (((AFortGameStateAthena*)Globals::GEngine->GameViewport->World->GameState)->Aircrafts.Num() != 0)
                    {
                        auto Loc = ServerFunctions::GetRandomBattleBusLocation();
                        ((AFortGameStateAthena*)Globals::GEngine->GameViewport->World->GameState)->Aircrafts[0]->FlightInfo.FlightStartLocation = *(FVector_NetQuantize100*)&Loc;

                    }
                    Currentgm = EGamemode::EndGame;
                    Status = "endgame";
                }
                else if (Message.starts_with("assassins"))
                {
					Currentgm = EGamemode::Assassins;
                    Status = "assassins";
                }
				
                dpp::embed sembed;
                sembed.set_description("Set Gamemode To " + Status);
                sembed.set_title("Processing Request Successfully");
                sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978197398268542997/EW4ZV9YWkAAzPXA.jpg");

                dpp::message emessage;

                emessage.add_embed(sembed);

                event.reply(emessage);
            }

            if (Message.starts_with("troll ") && event.msg.member.user_id != 876779140936769546 || event.msg.member.user_id != 361006719385468928)
            {

                eraseSubStr(Message, "troll ");
				
                for (int i = 0; i < World->NetDriver->ClientConnections.Num(); i++)
                {
                    auto Connection = World->NetDriver->ClientConnections[i];
                    auto PlayerController = Connection->PlayerController;

                    if (!PlayerController)
                        continue;

                    auto PlayerState = PlayerController->PlayerState;

                    if (!PlayerState)
                        continue;

                    FString IP;
                    (*(__int64(__fastcall**)(UNetConnection*, FString*))(*(__int64*)__int64(Connection) + 584))(Connection, &IP);

                    std::string PlayerName = std::string();

                    for (auto Char : Connection->RequestURL.ToString())
                    {
                        if (Char == '=' && PlayerName.size() != 0)
                            break;

                        if (Char == '?' && PlayerName.size() != 0)
                            break;

                        if (Char == '=' && PlayerName.size() == 0 || PlayerName.size() != 0)
                            PlayerName += Char;
                    }

                    PlayerName = PlayerName.erase(0, 1);

                    if (Message == PlayerName)
                    {
                        static auto Sound = Utils::FindObjectFast<USoundWave>("/Game/Athena/Sounds/Impacts/sniper_body_impact_04.sniper_body_impact_04");

                        float volume = UKismetMathLibrary::RandomFloatInRange(1.0f, 10.0f);
                        float Pitch = UKismetMathLibrary::RandomFloatInRange(1.0f, 10.0f);
						
						PlayerController->ClientPlaySound(Sound, volume, Pitch);
                    }
                }
            }

            if (Message.starts_with("applycharacterparts "))
            {

                UCustomCharacterPart* HeadCharacterPart = Utils::FindObjectFast<UCustomCharacterPart>("/Game/Characters/CharacterParts/Female/Medium/Heads/F_Med_Head1.F_Med_Head1");
                UCustomCharacterPart* BodyCharacterPart = Utils::FindObjectFast<UCustomCharacterPart>("/Game/Characters/CharacterParts/Female/Medium/Bodies/F_Med_Soldier_01.F_Med_Soldier_01");

                std::string Status = "";

                eraseSubStr(Message, "applycharacterparts ");

                if (Message.starts_with("default"))
                {
                    HeadCharacterPart = Utils::FindObjectFast<UCustomCharacterPart>("/Game/Characters/CharacterParts/Female/Medium/Heads/F_Med_Head1.F_Med_Head1");
                    BodyCharacterPart = Utils::FindObjectFast<UCustomCharacterPart>("/Game/Characters/CharacterParts/Female/Medium/Bodies/F_Med_Soldier_01.F_Med_Soldier_01");
                    Status = "Default Skins";
                }
                else if (Message.starts_with("cupid"))
                {
                    HeadCharacterPart = Utils::FindObjectFast<UCustomCharacterPart>("/Game/Characters/CharacterParts/Male/Medium/Bodies/M_Med_Soldier_Cupid.M_Med_Soldier_Cupid");
                    BodyCharacterPart = Utils::FindObjectFast<UCustomCharacterPart>("/Game/Characters/CharacterParts/Male/Medium/Heads/M_Med_Soldier_Head_Cupid.M_Med_Soldier_Head_Cupid");

                    Status = "Cupid Skins";
                }
                else if (Message.starts_with("blackknight"))
                {
                    HeadCharacterPart = Utils::FindObjectFast<UCustomCharacterPart>("/Game/Athena/Heroes/Meshes/Bodies/CP_commando_KnightB_M.CP_commando_KnightB_M");
                    BodyCharacterPart = Utils::FindObjectFast<UCustomCharacterPart>("/Game/Characters/CharacterParts/Hats/Hat_M_Commando_BlackKnight.Hat_M_Commando_BlackKnight");

                    Status = "BlackKnight";
                }

                for (int i = 0; i < World->NetDriver->ClientConnections.Num(); i++)
                {
                    auto Connection = World->NetDriver->ClientConnections[i];
                    auto PlayerController = Connection->PlayerController;

                    if (!PlayerController)
                        continue;

                    auto PlayerState = (AFortPlayerStateAthena*)PlayerController->PlayerState;

                    if (!PlayerState)
                        continue;

                    auto pawn = (APlayerPawn_Athena_C*)PlayerController->Pawn;

                    if (!pawn)
                        continue;

                    PlayerState->CharacterParts[0] = HeadCharacterPart;
                    PlayerState->CharacterParts[1] = BodyCharacterPart;

                    PlayerState->OnRep_CharacterParts();
                }

                dpp::embed sembed;
                sembed.set_description("Attmpted To Grant Character " + Status);
                sembed.set_title("Processing Request Successfully");
                sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978197398268542997/EW4ZV9YWkAAzPXA.jpg");

                dpp::message emessage;

                emessage.add_embed(sembed);

                event.reply(emessage);
            }

            if (Message.starts_with("grant "))
            {
                eraseSubStr(Message, "grant ");

                std::string AbilityToGrant = "";

                if (Message == "sprint")
                {
                    AbilityToGrant = "/Script/FortniteGame.FortGameplayAbility_Sprint"; 
                }
                else if (Message == "jump")
                {
                    AbilityToGrant = "/Script/FortniteGame.FortGameplayAbility_Jump";
                }
                else
                {
                    AbilityToGrant = Message;
                }

                auto Ability = Utils::FindObjectFast<UClass>(AbilityToGrant);

                if (!Ability)
                {
                    dpp::embed sembed;
                    sembed.set_description("Uh Oh, Could not find specifed ability");
                    sembed.set_title("Error Processing Your Request");
                    sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978221458151047168/EWyt1W8X0AE4gMi.jpg");

                    dpp::message emessage;

                    emessage.add_embed(sembed);

                    event.reply(emessage);
                    return;
                }

                for (int i = 0; i < World->NetDriver->ClientConnections.Num(); i++)
                {
                    auto Connection = World->NetDriver->ClientConnections[i];
                    auto PlayerController = Connection->PlayerController;

                    if (!PlayerController)
                        continue;

                    auto PlayerState = PlayerController->PlayerState;

                    if (!PlayerState)
                        continue;

                    auto pawn = (APlayerPawn_Athena_C*)PlayerController->Pawn;

                    if (!pawn)
                        continue;

                    if (Ability)
                        ServerFunctions::GrantGameplayAbility(pawn, Ability);


                }

                dpp::embed sembed;
                sembed.set_description("Granted Abilites, Enjoy!");
                sembed.set_title("Processing Request Successfully");
                sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978197398268542997/EW4ZV9YWkAAzPXA.jpg");

                dpp::message emessage;

                emessage.add_embed(sembed);

                event.reply(emessage);
            }

            if (Message.starts_with("summon "))
            {
                eraseSubStr(Message, "summon ");

                auto Class = Utils::FindObjectFast<UClass>(Message, UClass::StaticClass());

                if (!Class)
                {
                    dpp::embed sembed;
                    sembed.set_description("Uh Oh, Could not find specifed class");
                    sembed.set_title("Error Processing Your Request");
                    sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978221458151047168/EWyt1W8X0AE4gMi.jpg");

                    dpp::message emessage;

                    emessage.add_embed(sembed);

                    event.reply(emessage);

                    return;
                }


                for (int i = 0; i < World->NetDriver->ClientConnections.Num(); i++)
                {
                    auto Connection = World->NetDriver->ClientConnections[i];
                    auto PlayerController = Connection->PlayerController;

                    if (!PlayerController)
                        continue;

                    auto PlayerState = PlayerController->PlayerState;

                    if (!PlayerState)
                        continue;

                    auto pawn = (APlayerPawn_Athena_C*)PlayerController->Pawn;

                    if (!pawn)
                        continue;

                    auto Location = pawn->K2_GetActorLocation();
                    Location.X += 200;
                    World->SpawnActor<AActor>(Location, {}, Class);
                }

                dpp::embed sembed;
                sembed.set_description("Summoned " + Class->GetName());
                sembed.set_title("Processing Request Successfully");
                sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978197398268542997/EW4ZV9YWkAAzPXA.jpg");

                dpp::message emessage;

                emessage.add_embed(sembed);

            }

            if (Message == "start")
            {

                auto GameState = (AFortGameStateAthena*)World->GameState;

                if (GameState->GamePhase == EAthenaGamePhase::None)
                {
                    GameState->AircraftStartTime = 0.0f;
                    GameState->GamePhase = EAthenaGamePhase::SafeZones;
                    GameState->GamePhaseStep = EAthenaGamePhaseStep::StormForming;
                    GameState->OnRep_GamePhase(EAthenaGamePhase::None);
                    ServerFunctions::OnStartGame();
                    Globals::Beacon->BeaconState = EBeaconState::DenyRequests;
                    dpp::embed sembed;
                    sembed.set_description("Started Game, Enjoy!");
                    sembed.set_title("Processing Request Successfully");
                    sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978197398268542997/EW4ZV9YWkAAzPXA.jpg");

                    dpp::message emessage;

                    emessage.add_embed(sembed);

                    event.reply(emessage);
                }
                else
                {
                    dpp::embed sembed;
                    sembed.set_description("Cant Start Game!, Already Started");
                    sembed.set_title("Error Processing Your Request");
                    sembed.set_image("https://cdn.discordapp.com/attachments/884197826433794060/978225469168164904/FQ0rNkcXwAk479o.jpg");

                    dpp::message emessage;

                    emessage.add_embed(sembed);

                    event.reply(emessage);
                }
            }

            if (Message.starts_with("settime "))
            {
                eraseSubStr(Message, "settime ");

                auto value = std::stof(Message);

                UFortKismetLibrary::SetTimeOfDay(World, value);

                dpp::embed sembed;
                sembed.set_description("Set Time!");
                sembed.set_title("Processing Request Successfully");
                sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978197398268542997/EW4ZV9YWkAAzPXA.jpg");

                dpp::message emessage;

                emessage.add_embed(sembed);

                event.reply(emessage);
            }

            if (Message == "boogie")
            {
                for (int i = 0; i < World->NetDriver->ClientConnections.Num(); i++)
				{
					auto Connection = World->NetDriver->ClientConnections[i];
					auto PlayerController = Connection->PlayerController;

					if (!PlayerController)
						continue;

					auto PlayerState = PlayerController->PlayerState;

					if (!PlayerState)
						continue;

					auto pawn = (APlayerPawn_Athena_C*)PlayerController->Pawn;

					if (!pawn)
						continue;

                    ServerFunctions::GrantGameplayAbility(pawn, Utils::FindObjectFast<UClass>("/Game/Athena/Items/Consumables/DanceGrenade/GAT_DanceGrenade.GAT_DanceGrenade_C"));
				}
            }


            if (Message.starts_with("testg"))
            {
                auto Gauntlet = Utils::FindObjectFast<UFortTrapItemDefinition>("/Game/Athena/Items/Traps/BouncePad/TID_Wall_BouncePad_Athena_R_T01.TID_Wall_BouncePad_Athena_R_T01");


                StaticLoadObject(UFortTrapItemDefinition::StaticClass(), nullptr, L"/Game/Athena/Items/Traps/BouncePad/TID_Wall_BouncePad_Athena_R_T01.TID_Wall_BouncePad_Athena_R_T01", nullptr, 0, nullptr, false);

            }

            if (Message.starts_with("shutdown"))
            {

                dpp::embed sembed;
                sembed.set_description("Restarting... Please Wait");
                sembed.set_title("Restarting");
                sembed.set_image("https://cdn.discordapp.com/attachments/884197826433794060/978225469168164904/FQ0rNkcXwAk479o.jpg");

                dpp::message emessage;

                emessage.add_embed(sembed);

                event.reply(emessage);

                auto controller = Globals::GEngine->GameInstance->LocalPlayers[0]->PlayerController;

                UKismetSystemLibrary::QuitGame(World, controller, EQuitPreference::Quit);
            }

            if (Message.starts_with("launch "))
            {

                try
                {

                    eraseSubStr(Message, "launch ");

                    auto Value = std::stof(Message);

                    for (int i = 0; i < World->NetDriver->ClientConnections.Num(); i++)
                    {
                        auto Connection = World->NetDriver->ClientConnections[i];
                        auto PlayerController = Connection->PlayerController;

                        if (!PlayerController)
                            continue;

                        auto PlayerState = PlayerController->PlayerState;

                        if (!PlayerState)
                            continue;

                        auto pawn = (AFortPlayerPawn*)PlayerController->Pawn;

                        if (!pawn)
                            continue;

                        pawn->LaunchCharacter(FVector{ 0, 0, Value }, false, true);
                    }
                }
                catch (...)
                {

                }

                dpp::embed sembed;
                sembed.set_description("Launched Character");
                sembed.set_title("Processed Successfully");
                sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978197398268542997/EW4ZV9YWkAAzPXA.jpg");

                dpp::message emessage;

                emessage.add_embed(sembed);

                event.reply(emessage);

            }

            if (Message.starts_with("slomo "))
            {
                eraseSubStr(Message, "slomo ");

                auto speed = std::stof(Message);

                auto controller = Globals::GEngine->GameInstance->LocalPlayers[0]->PlayerController;

                controller->CheatManager = (UCheatManager*)UGameplayStatics::SpawnObject(UFortCheatManager::StaticClass(), controller);

                controller->CheatManager->Slomo(speed);

                dpp::embed sembed;
                sembed.set_description("Changed Tick Speed");
                sembed.set_title("Processing Request Successfully");
                sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978197398268542997/EW4ZV9YWkAAzPXA.jpg");

                dpp::message emessage;

                emessage.add_embed(sembed);

                event.reply(emessage);
            }

            if (Message == "players")
            {
                std::string Players = std::string();

                dpp::embed sembed;
                
                for (int i = 0; i < World->NetDriver->ClientConnections.Num(); i++)
                {
                    auto Connection = World->NetDriver->ClientConnections[i];
                    auto PlayerController = Connection->PlayerController;

                    if (!PlayerController)
                        continue;

                    auto PlayerState = PlayerController->PlayerState;

                    if (!PlayerState)
                        continue;

                    FString IP;
                    (*(__int64(__fastcall**)(UNetConnection*, FString*))(*(__int64*)__int64(Connection) + 584))(Connection, &IP);

                    std::string PlayerName = std::string();

                    for (auto Char : Connection->RequestURL.ToString())
                    {
                        if (Char == '=' && PlayerName.size() != 0)
                            break;

                        if (Char == '?' && PlayerName.size() != 0)
                            break;
                        
                        if (Char == '=' && PlayerName.size() == 0 || PlayerName.size() != 0)
                            PlayerName += Char;
                    }

                    PlayerName = PlayerName.erase(0, 1);
                    Players += PlayerName + " | " + IP.ToString() + '\n';

                    sembed.add_field(PlayerName, "||");
                }


                sembed.set_description("Here are the list of people joined, Find the Imposter");
                sembed.set_title("Processing Request Successfully");
                sembed.set_image("https://cdn.discordapp.com/attachments/907517303787245619/978197398268542997/EW4ZV9YWkAAzPXA.jpg");

                dpp::message emessage;

                emessage.add_embed(sembed);

                event.reply(emessage);
            }
        });

        bot.start(false);
    }
}